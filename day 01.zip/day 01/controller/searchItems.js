app_controllers.controller('searchItems', function($scope){

});